import course from './course.json';
import {Study} from './study-engine.js';
import questions from './questions.json';
const COOKIE='wt_session';const ITERATIONS=100000;const AGE=30*86400;
const enc=new TextEncoder();const options=new Map(questions.map(q=>[q.word,q.options]));
const hex=(b:ArrayBuffer|Uint8Array)=>Array.from(b instanceof Uint8Array?b:new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');
const random=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
async function digest(s:string){return hex(await crypto.subtle.digest('SHA-256',enc.encode(s)));}
async function passwordHash(password:string,salt:string){const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc.encode(salt),iterations:ITERATIONS},key,256));}
function equal(a:string,b:string){let diff=a.length^b.length;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^(b.charCodeAt(i)||0);return diff===0;}
function json(body:unknown,status=200,cookie?:string){const headers:Record<string,string>={'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};if(cookie)headers['Set-Cookie']=cookie;return new Response(JSON.stringify(body),{status,headers});}
const cookie=(token:string,age=AGE)=>`${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${age}`;
async function rate(db:any,key:string,max:number,seconds:number){const now=Math.floor(Date.now()/1000);const row=await db.prepare('INSERT INTO limits (key,count,expires) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN expires<=? THEN 1 ELSE count+1 END, expires=CASE WHEN expires<=? THEN excluded.expires ELSE expires END RETURNING count').bind(key,now+seconds,now,now).first();return row.count<=max;}
async function current(req:Request,db:any){const token=req.headers.get('Cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith(COOKIE+'='))?.slice(COOKIE.length+1);if(!token||!/^[a-f0-9]{64}$/.test(token))return null;const tokenHash=await digest(token);const p=await db.prepare('SELECT players.id,players.nick FROM sessions JOIN players ON players.id=sessions.player_id WHERE token_hash=? AND expires>?').bind(tokenHash,Math.floor(Date.now()/1000)).first();return p?{...p,tokenHash}:null;}
async function progress(db:any,id:string){
 const {results}=await db.prepare('SELECT word,choice,hint,created FROM answers WHERE player_id=? ORDER BY created,rowid').bind(id).all();
 const answers=Object.fromEntries(results.map((a:any)=>[a.word,{choice:a.choice,hint:!!a.hint,date:new Date(a.created*1000).toISOString()}]));
 const patch=Study.migrate(answers,course);
 if(Object.keys(patch).length){await db.batch(Object.entries(patch).map(([word,a]:[string,any])=>db.prepare('INSERT INTO answers (player_id,word,choice,hint,created) VALUES (?,?,?,?,?) ON CONFLICT(player_id,word) DO NOTHING').bind(id,word,a.choice,a.hint?1:0,Math.floor(Date.now()/1000))));Object.assign(answers,patch);}

 return answers;
}
async function session(db:any,id:string){const token=random(),now=Math.floor(Date.now()/1000);await db.batch([db.prepare('DELETE FROM sessions WHERE player_id=? AND expires<=?').bind(id,now),db.prepare('INSERT INTO sessions (token_hash,player_id,expires) VALUES (?,?,?)').bind(await digest(token),id,now+AGE)]);return token;}
export async function handle(req:Request,db:any,action:string){
 try{
 if(!db)return json({error:'Сервис временно недоступен. Попробуй позже.'},503);
 if(req.method==='GET'&&action==='me'){const p=await current(req,db);return json(p?{player:{nick:p.nick},answers:await progress(db,p.id)}:{player:null});}
 if(req.method!=='POST')return json({error:'Метод не поддерживается.'},405);
 const origin=req.headers.get('Origin');if(!origin||origin!==new URL(req.url).origin)return json({error:'Запрос отклонён. Обнови страницу.'},403);
 if(!req.headers.get('Content-Type')?.includes('application/json'))return json({error:'Неверный формат запроса.'},415);
 if(Number(req.headers.get('Content-Length')||0)>250000)return json({error:'Слишком большой запрос.'},413);
 const raw=await req.text();if(raw.length>250000)return json({error:'Слишком большой запрос.'},413);
 let body:any;try{body=JSON.parse(raw);}catch{return json({error:'Неверный формат запроса.'},400);}if(!body||typeof body!=='object')return json({error:'Неверный запрос.'},400);
 if(action==='register'||action==='login'){
 const ip=req.headers.get('CF-Connecting-IP')||'unknown';const ipKey=await digest(ip);if(!await rate(db,'auth:'+ipKey,35,900))return json({error:'Слишком много попыток. Подожди 15 минут.'},429);
 const nick=typeof body.nick==='string'?body.nick.trim().normalize('NFKC'):'';const pass=body.password;
 if(!/^[\p{L}\p{N}_-]{3,24}$/u.test(nick)||typeof pass!=='string'||pass.length<8||pass.length>128)return json({error:'Ник: 3–24 буквы, цифры, _ или -. Пароль: 8–128 символов.'},400);
 const nickKey=nick.toLocaleLowerCase('en-US');if(!await rate(db,'nick:'+await digest(nickKey),12,900))return json({error:'Слишком много попыток для этого ника. Подожди 15 минут.'},429);
 if(action==='register'){
 if(!await rate(db,'register:'+ipKey,5,3600))return json({error:'Слишком много регистраций. Попробуй через час.'},429);
 if(await db.prepare('SELECT id FROM players WHERE nick_key=?').bind(nickKey).first())return json({error:'Этот ник уже занят. Выбери другой.'},409);
 const id=crypto.randomUUID(),salt=random(),hash=await passwordHash(pass,salt);
 try{await db.prepare('INSERT INTO players (id,nick,nick_key,salt,hash,created) VALUES (?,?,?,?,?,?)').bind(id,nick,nickKey,salt,hash,Math.floor(Date.now()/1000)).run();}catch(e:any){if(String(e).includes('UNIQUE'))return json({error:'Этот ник уже занят. Выбери другой.'},409);throw e;}
 return json({player:{nick},answers:await progress(db,id)},201,cookie(await session(db,id)));
 }
 const p=await db.prepare('SELECT * FROM players WHERE nick_key=?').bind(nickKey).first();const candidate=await passwordHash(pass,p?.salt||'constant-dummy-salt-for-timing');
 if(!p||!equal(candidate,p.hash))return json({error:'Ник или пароль не подходит.'},401);
 return json({player:{nick:p.nick},answers:await progress(db,p.id)},200,cookie(await session(db,p.id)));
 }
 const p=await current(req,db);if(!p)return json({error:'Войди в аккаунт ещё раз.'},401);
 if(action==='logout'){await db.prepare('DELETE FROM sessions WHERE token_hash=?').bind(p.tokenHash).run();return json({ok:true},200,cookie('',0));}

 if(action==='password'){
 if(!await rate(db,'password:'+p.id,6,900))return json({error:'Слишком много попыток. Подожди 15 минут.'},429);
 if(typeof body.currentPassword!=='string'||body.currentPassword.length>128||typeof body.newPassword!=='string'||body.newPassword.length<8||body.newPassword.length>128)return json({error:'Новый пароль должен содержать от 8 до 128 символов.'},400);
 if(body.currentPassword===body.newPassword)return json({error:'Выбери новый пароль, отличный от текущего.'},400);
 const row=await db.prepare('SELECT salt,hash FROM players WHERE id=?').bind(p.id).first();
 if(!row||!equal(await passwordHash(body.currentPassword,row.salt),row.hash))return json({error:'Текущий пароль не подходит.'},401);
 const salt=random(),hash=await passwordHash(body.newPassword,salt);
 const result=await db.prepare('UPDATE players SET salt=?,hash=? WHERE id=? AND hash=?').bind(salt,hash,p.id,row.hash).run();
 if(!result.meta.changes)return json({error:'Пароль уже изменился. Войди заново.'},409);
 await db.prepare('DELETE FROM sessions WHERE player_id=?').bind(p.id).run();
 return json({ok:true},200,cookie(await session(db,p.id)));
 }
 if(action==='study'){
 const prior=await progress(db,p.id);let result;
 try{result=Study.transition(prior,course,body);}catch(e:any){return json({error:e.message},409);}
 const key=body.kind?.startsWith('lesson-')?Study.attemptKey(body.lesson):Study.bossKey(body.checkpoint),primary=result.patch[key];
 if(primary){
  const now=Math.floor(Date.now()/1000),previous=prior[key]?.choice||null;
  const statements=[db.prepare('INSERT INTO answers (player_id,word,choice,hint,created) VALUES (?,?,?,0,?) ON CONFLICT(player_id,word) DO UPDATE SET choice=excluded.choice,created=excluded.created WHERE answers.choice=?').bind(p.id,key,primary.choice,now,previous)];
  for(const [word,a] of Object.entries(result.patch) as [string,any][]){if(word===key)continue;statements.push(db.prepare('INSERT INTO answers (player_id,word,choice,hint,created) SELECT ?,?,?,?,? WHERE (SELECT choice FROM answers WHERE player_id=? AND word=?)=? ON CONFLICT(player_id,word) DO UPDATE SET choice=excluded.choice,hint=excluded.hint,created=excluded.created').bind(p.id,word,a.choice,a.hint?1:0,now,p.id,key,primary.choice));}
  await db.batch(statements);
  const saved=await db.prepare('SELECT choice FROM answers WHERE player_id=? AND word=?').bind(p.id,key).first();
  if(saved?.choice!==primary.choice)return json({error:'Прогресс изменился на другом устройстве. Продолжи с сохранённого места.'},409);
 }
 return json(result);
 }
 if(action==='import'){
 const prior=await progress(db,p.id),entries=body.answers;
 if(!Array.isArray(entries)||entries.length<1||entries.length>questions.length||entries.some((a:any)=>!a||typeof a.word!=='string'||typeof a.choice!=='string'||!options.get(a.word)?.includes(a.choice)||typeof a.hint!=='boolean'))return json({error:'Некорректные ответы.'},400);
 const merged={...prior};const patch:Record<string,any>={};
 for(const a of entries){if(!merged[a.word])patch[a.word]=merged[a.word]={choice:a.choice,hint:a.hint,date:new Date().toISOString()};if(a.mastered===true)patch['__wt_mastery_v1:'+a.word]=merged['__wt_mastery_v1:'+a.word]=Study.record(a.word);}
 const count=Number.isInteger(body.completedLessons)?Math.min(body.completedLessons,course.length):0;
 for(let i=0;i<count;i++){if(!course[i].items.every(q=>merged[q[0]]?.choice===q[0]||merged['__wt_mastery_v1:'+q[0]]?.choice===q[0]))break;patch[Study.lessonKey(i)]=Study.record('true');}
 // Guest checkpoints remain earned only when all their lessons were imported.
 const bossCount=Math.min(Math.floor(count/5),40);for(let i=1;i<=bossCount;i++){const cp=i*5;if(body.passedBosses?.includes(cp)&&course.slice(0,cp).every((_,n)=>prior[Study.lessonKey(n)]||patch[Study.lessonKey(n)]))patch[Study.bossPassKey(cp)]=Study.record('true');}
 if(Object.keys(patch).length)await db.batch(Object.entries(patch).map(([word,a]:[string,any])=>db.prepare('INSERT INTO answers (player_id,word,choice,hint,created) VALUES (?,?,?,?,?) ON CONFLICT(player_id,word) DO NOTHING').bind(p.id,word,a.choice,a.hint?1:0,Math.floor(Date.now()/1000))));
 return json({answers:await progress(db,p.id)});
 }
 if(['answer','correct','boss-start','boss-answer','boss-retry'].includes(action))return json({error:'Игра обновлена. Обнови страницу, чтобы продолжить.'},409);
 return json({error:'Не найдено.'},404);
 }catch{return json({error:'Не удалось сохранить данные. Попробуй ещё раз.'},500);}
}
