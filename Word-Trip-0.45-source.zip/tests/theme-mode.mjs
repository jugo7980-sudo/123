import assert from 'node:assert/strict';
import {harness,ready} from './ui-harness.mjs';

const h=await ready(harness(async()=>({ok:true,json:async()=>({player:null})})));
const key='word-trip-theme-v1';
assert(h.buttons().some(b=>b.dataset.action==='toggleTheme'),'theme control is visible on the home screen');
await h.click('action','toggleTheme');
assert.equal(h.c.document.documentElement.dataset.theme,'light');
assert.equal(h.disk[key],'light','theme preference persists');

await h.click('action','start');
assert.equal(h.run('state.screen'),'question');
assert(h.buttons().some(b=>b.dataset.action==='toggleTheme'),'theme control is visible in lessons');
await h.click('action','toggleTheme');
assert.equal(h.c.document.documentElement.dataset.theme,'dark');
assert.equal(h.run('state.screen'),'question','theme changes do not interrupt the current question');

const answers=h.run(`(()=>{let a={};for(let n=0;n<5;n++){let t=Study.transition(a,missions,{kind:'lesson-start',lesson:n,order:[0,1,2,3,4],restart:false});a={...a,...t.patch};for(let i=0;i<5;i++){t=Study.transition(a,missions,{kind:'lesson-answer',lesson:n,round:0,index:i,choice:missions[n].items[i][0]});a={...a,...t.patch};}}return a;})()`);
h.run('state.answers='+JSON.stringify(answers));
h.run('progressChanged();home()');
await h.click('action','start');
assert.equal(h.run('state.screen'),'boss');
assert(h.buttons().some(b=>b.dataset.action==='toggleTheme'),'theme control is visible in bosses');
await h.click('action','toggleTheme');
assert.equal(h.run('state.screen'),'boss','theme changes do not interrupt the boss');
assert.equal(h.c.document.documentElement.dataset.theme,'light');
console.log('PASS: light/dark mode persists and can be switched on home, lesson, and boss screens.');
