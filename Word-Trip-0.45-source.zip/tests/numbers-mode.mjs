import assert from 'node:assert/strict';
import {harness,ready} from './ui-harness.mjs';
import fs from 'node:fs';

const h=await ready(harness(async()=>({ok:true,json:async()=>({player:null})})));
assert.equal(h.run('numberLessons.length'),20);
assert.equal(h.run('numberLessons.flatMap(x=>x.numbers).length'),100);
assert.equal(h.run('numberWord(1)'),'one');
assert.equal(h.run('numberWord(13)'),'thirteen');
assert.equal(h.run('numberWord(40)'),'forty');
assert.equal(h.run('numberWord(58)'),'fifty-eight');
assert.equal(h.run('numberWord(100)'),'one hundred');
assert.equal(h.run('numberRussian(58)'),'пятьдесят восемь');
assert.equal(h.run('numberRussian(100)'),'сто');
assert.match(h.app.innerHTML,/УРОКИ ЧИСЕЛ/);
assert.match(h.app.innerHTML,/Числа от 1 до 100/);
assert(!h.app.innerHTML.includes('Следующие шаги'),'homepage keeps the lesson roadmap out of the main screen');
await h.click('action','numberLessons');
assert.equal(h.run('state.screen'),'numberLessons');
assert.equal(h.buttons().filter(b=>b.dataset.numberLesson!==undefined).length,20);
assert.equal(h.buttons().filter(b=>b.dataset.numberBoss!==undefined).length,4,'four checkpoint bosses should be visible');
assert(h.buttons().find(b=>b.dataset.numberLesson==='1').disabled,'lesson 2 must stay locked');
await h.click('action','numbersHome');
assert.equal(h.run('state.screen'),'numbers');
assert.match(h.app.innerHTML,/Счёт до 100/);
await h.click('action','numberLessons');
await h.click('numberLesson',0);
assert.equal(h.run('state.screen'),'numberQuestion');
assert(h.buttons().some(b=>b.dataset.action==='numberListen'));
assert(h.buttons().some(b=>b.dataset.action==='numberListenSlow'));
assert(h.buttons().some(b=>b.dataset.action==='toggleSound'));
assert(h.app.innerHTML.includes('number-answers'));
assert.match(fs.readFileSync('public/style.css','utf8'),/\.number-answers\{[^}]*margin-top:28px/,'number answer choices have extra separation below the audio controls');
let order=Array.from(h.run('numberRound.questions'));
await h.click('action','numberHint');
assert.match(h.app.innerHTML,/Подсказка: точный перевод числа/);
assert.match(h.app.innerHTML,/один|два|три|четыре|пять/);
assert(!h.app.innerHTML.includes('Как по-английски число'));
assert.equal(h.buttons().filter(b=>b.dataset.numberChoice!==undefined).length,0,'hint hides the question choices');
assert(h.buttons().some(b=>b.dataset.action==='numberListen'));
assert(h.buttons().some(b=>b.dataset.action==='numberListenSlow'));
await h.click('action','retryNumber');
assert.equal(h.run('numberRound.round'),1);
assert.notDeepEqual(Array.from(h.run('numberRound.questions')),order,'hint retry must reshuffle the lesson');
order=Array.from(h.run('numberRound.questions'));
let wrong=h.run('numberWord(numberRound.questions[0])');
wrong=h.buttons().find(b=>b.dataset.numberChoice!==undefined&&b.dataset.numberChoice!==wrong).dataset.numberChoice;
await h.click('numberChoice',wrong);
assert.match(h.app.innerHTML,/Неверно/);
assert(h.buttons().some(b=>b.dataset.action==='retryNumber'));
await h.click('action','retryNumber');
assert.equal(h.run('numberRound.round'),2);
assert.notDeepEqual(Array.from(h.run('numberRound.questions')),order,'wrong-answer retry must reshuffle the lesson');
for(let lesson=0;lesson<20;lesson++){
  if(lesson>0&&h.run('state.screen')==='numberResult')await h.click('action','startNumberNext');
  for(let q=0;q<5;q++){
    const correct=h.run('numberWord(numberRound.questions[numberRound.index])');
    const answers=h.buttons().filter(b=>b.dataset.numberChoice!==undefined);
    assert.equal(answers.length,6,'every number question must have six choices');
    assert.equal(new Set(answers.map(b=>b.dataset.numberChoice)).size,6);
    assert(answers.some(b=>b.dataset.numberChoice===correct),'the correct number name must be among the choices');
    await h.click('numberChoice',correct);
    assert.match(h.app.innerHTML,new RegExp(correct.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
    await h.click('action','numberNext');
  }
  assert.equal(h.run('numberLessonPassed('+lesson+')'),true);
  assert.equal(h.run('numberTotal()'),(lesson+1)*5);
  if(lesson<19){
    assert.equal(h.run('state.screen'),'numberResult');
    await h.click('action','startNumberNext');
    if((lesson+1)%5===0){
      const checkpoint=lesson+1;
      assert.equal(h.run('state.screen'),'numberBoss','boss should start after each five lessons');
      assert.equal(h.run('numberDueBoss()'),checkpoint);
      assert(h.buttons().some(b=>b.dataset.action==='toggleSound'),'number bosses have a sound toggle');
      const oldBossOrder=Array.from(h.run('numberBoss.questions'));
      if(checkpoint===5){
        for(let error=0;error<3;error++){
          const correct=h.run('numberWord(numberBoss.questions[numberBoss.index])');
          const wrong=h.buttons().find(b=>b.dataset.numberBossChoice!==undefined&&b.dataset.numberBossChoice!==correct).dataset.numberBossChoice;
          const answers=h.buttons().filter(b=>b.dataset.numberBossChoice!==undefined);
          assert.equal(answers.length,10,'boss questions must have ten choices');
          assert.equal(new Set(answers.map(b=>b.dataset.numberBossChoice)).size,10);
          await h.click('numberBossChoice',wrong);
          if(error<2)await h.click('action','numberBossNext');
        }
        assert.match(h.app.innerHTML,/Три ошибки/);
        await h.click('action','numberBossRestart');
        assert.equal(h.run('numberBoss.round'),1);
        assert.notDeepEqual(Array.from(h.run('numberBoss.questions')),oldBossOrder,'failed boss retry must reshuffle all questions');
        assert.equal(h.run('numberBoss.errors'),0);
        const firstChoices=h.buttons().filter(b=>b.dataset.numberBossChoice!==undefined).map(b=>b.dataset.numberBossChoice);
        const firstCorrect=h.run('numberWord(numberBoss.questions[numberBoss.index])');
        await h.click('numberBossChoice',firstCorrect);
        await h.click('action','numberBossNext');
        const resumeIndex=h.run('numberBoss.index'),resumeChoices=h.buttons().filter(b=>b.dataset.numberBossChoice!==undefined).map(b=>b.dataset.numberBossChoice);
        await h.click('action','numbersHome');
        await h.click('numberBoss',checkpoint);
        assert.equal(h.run('numberBoss.index'),resumeIndex,'boss attempt restores after leaving route');
        assert.deepEqual(h.buttons().filter(b=>b.dataset.numberBossChoice!==undefined).map(b=>b.dataset.numberBossChoice),resumeChoices,'boss choices stay stable while resuming');
      }
      while(h.run('state.screen')==='numberBoss'){
        const correct=h.run('numberWord(numberBoss.questions[numberBoss.index])');
        const answers=h.buttons().filter(b=>b.dataset.numberBossChoice!==undefined);
        assert.equal(answers.length,10);
        assert.equal(new Set(answers.map(b=>b.dataset.numberBossChoice)).size,10);
        assert(answers.some(b=>b.dataset.numberBossChoice===correct),'boss answer set contains the correct number');
        await h.click('numberBossChoice',correct);
        await h.click('action','numberBossNext');
      }
      assert.equal(h.run('numberBossPassed('+checkpoint+')'),true);
      assert.equal(h.run('state.screen'),'numberBossResult');
      if(checkpoint<20)await h.click('action','numberBossContinue');
    }
  }
}
if(h.run('state.screen')==='numberResult'){
  await h.click('action','startNumberNext');
  assert.equal(h.run('state.screen'),'numberBoss','final checkpoint also has a boss');
  for(let q=0;q<25;q++){
    const correct=h.run('numberWord(numberBoss.questions[numberBoss.index])');
    assert.equal(h.buttons().filter(b=>b.dataset.numberBossChoice!==undefined).length,10);
    await h.click('numberBossChoice',correct);
    await h.click('action','numberBossNext');
  }
}
assert.equal(h.run('numberTotal()'),100);
assert.equal(h.run('nextNumberLesson()'),20);
assert.equal(h.run('numberProgress.bosses.length'),4);
assert.equal(h.run('JSON.parse(localStorage.getItem(NUMBER_PROGRESS_KEY)).completed.length'),20);
console.log('PASS number course and bosses: 20 sequential lessons, four 25-number bosses, ten choices, three-error shuffled retry, progress gates, exact feedback, sound control, saved progress.');
