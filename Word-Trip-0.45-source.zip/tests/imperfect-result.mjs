import assert from 'node:assert/strict';
import fs from 'node:fs';
import {harness,ready} from './ui-harness.mjs';
const course=JSON.parse(fs.readFileSync('lib/course.json'));
const h=await ready(harness(async()=>({ok:true,json:async()=>({player:null})})));
await h.click('action','start');
let q=course[0].items[h.run('state.attempt.questions[state.index]')];
await h.click('choice',q[5].find(w=>w!==q[0]));
assert(h.buttons().some(b=>b.dataset.action==='retryLesson'&&b.text.includes('Хорошо')));
await h.click('action','retryLesson');
for(let i=0;i<5;i++){
 q=course[0].items[h.run('state.attempt.questions[state.index]')];
 await h.click('choice',q[0]);await h.click('action','next');
}
assert.equal(h.run('state.screen'),'result');
assert.equal(h.run('state.attempt.round'),1);
assert(h.buttons().some(b=>b.dataset.action==='reviewLesson'&&b.text.includes('Начать заново')));
console.log('PASS: lesson completed after a restart shows “Начать заново”.');
