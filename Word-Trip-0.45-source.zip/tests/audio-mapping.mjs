import assert from 'node:assert/strict';
import fs from 'node:fs';
import {harness,ready} from './ui-harness.mjs';
const course=JSON.parse(fs.readFileSync('lib/course.json'));
const all=course.flatMap(m=>m.items);
const h=await ready(harness(async()=>({ok:true,json:async()=>({player:null})})));
const spoken=[];h.c.window.speechSynthesis.speak=u=>spoken.push({text:u.text,rate:u.rate});
for(const q of all){
 h.run(`state.screen='boss';state.boss={words:[${JSON.stringify(q[0])}],index:0};state.bossIndex=0;state.feedback={choice:${JSON.stringify(q[0])}};queueBossWord(${JSON.stringify(q[0])})`);h.drain();
 assert.deepEqual(spoken.at(-1),{text:q[0],rate:.9},`boss should speak only the correct answer ${q[0]}`);
}
assert.equal(spoken.length,all.length);
assert(all.every(q=>(q[2].match(/___/g)||[]).length===1),'every lesson sentence has one answer blank');
console.log('PASS: boss auto-speech says only the correct English word for all 1000 course words.');
