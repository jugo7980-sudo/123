import assert from 'node:assert/strict';
import fs from 'node:fs';
import {Study} from '../lib/study-engine.js';
import {harness,ready} from './ui-harness.mjs';
import {setup} from './api-harness.mjs';
const course=JSON.parse(fs.readFileSync('lib/course.json'));
for(const kind of ['lesson','boss'])for(const errors of [0,1,2,3]){
 let a={...Study.migrate({},course)};
 if(kind==='boss')for(let i=0;i<5;i++)a[Study.lessonKey(i)]=Study.record('true');
 const start=kind==='lesson'?{kind:'lesson-start',lesson:0,order:[0,1,2,3,4]}:{kind:'boss-start',checkpoint:5,words:Study.bossWords(5,course)};
 let r=Study.transition(a,course,start);Object.assign(a,r.patch);
 const length=kind==='lesson'?5:25;
 for(let i=0;i<length;i++){
  const v=kind==='lesson'?r.view.attempt:r.view.boss;
  const word=kind==='lesson'?course[0].items[i][0]:v.words[i];
  const opts=kind==='lesson'?Study.lessonOptions(course[0].items[i],course):Study.options(v.words,word,course);
  r=Study.transition(a,course,{kind:kind+'-answer',lesson:0,checkpoint:5,round:v.round,index:i,choice:i<errors?opts.find(x=>x!==word):word});Object.assign(a,r.patch);
  const now=kind==='lesson'?r.view.attempt:r.view.boss;
  if(i===2&&errors===3){assert(now.failed);assert(!now.done);break;}
 }
 const key=kind==='lesson'?Study.lessonKey(0):Study.bossPassKey(5);
 if(errors<3)assert.equal(a[key+':stars'].choice,String(3-errors));else {assert(!a[key]);r=Study.transition(a,course,{...start,restart:true});const v=kind==='lesson'?r.view.attempt:r.view.boss;assert.equal(v.errors,0);assert.equal(v.index,0);}
}
const api=await setup();
try{
 const p=await api.player('StarsQA');const h=await ready(harness(p.fetcher));
 await h.run('launchLesson(0,true)');
 for(let i=0;i<5;i++){
  const choice=h.run(`(()=>{const q=missions[0].items[state.attempt.questions[state.index]];return ${i<2?'Study.lessonOptions(q,missions).find(w=>w!==q[0])':'q[0]'};})()`);
  await h.click('choice',choice);await h.click('action','next');
 }
 assert.equal(h.run('state.screen'),'result');assert(h.app.innerHTML.includes('1 из 3 звёзд'));
 const reload=await ready(harness(p.fetcher));await reload.run('lessons()');assert(reload.app.innerHTML.includes('1 из 3 звёзд'));
 await h.run('launchLesson(0,true)');
 for(let i=0;i<3;i++){await h.click('choice',h.run('(()=>{const q=missions[0].items[state.attempt.questions[state.index]];return Study.lessonOptions(q,missions).find(w=>w!==q[0]);})()'));if(i<2)await h.click('action','next');}
 await h.click('action','retryLesson');assert.equal(h.run('state.attempt.errors'),0);assert.equal(h.run('state.index'),0);
}finally{await api.mf.dispose();}
for(const boss of [false,true])for(const errors of [0,1,2,3]){
 const h=await ready(harness(async()=>({ok:true,json:async()=>({player:null})})));
 if(boss)h.run('numberProgress.completed=[0,1,2,3,4];launchNumberBoss(5)');else h.run('launchNumberLesson(0)');
 const round=boss?'numberBoss':'numberRound', attr=boss?'numberBossChoice':'numberChoice', next=boss?'numberBossNext':'numberNext';
 for(let i=0;i<(boss?25:5);i++){
  const correct=h.run(`numberWord(${round}.questions[${round}.index])`),choice=i<errors?h.buttons().find(b=>b.dataset[attr]&&b.dataset[attr]!==correct).dataset[attr]:correct;
  await h.click(attr,choice);
  if(i===2&&errors===3){await h.click('action',boss?'numberBossRestart':'retryNumber');assert.equal(h.run(round+'.errors'),0);assert.equal(h.run(round+'.index'),0);break;}
  await h.click('action',next);
 }
 if(errors<3){assert(h.app.innerHTML.includes(`${3-errors} из 3 звёзд`));const reloaded=await ready(harness(async()=>({ok:true,json:async()=>({player:null})}),h.disk));assert.equal(reloaded.run(`numberProgress.stars['${boss?'boss:5':'lesson:0'}']`),3-errors);}
}
console.log('PASS: all four modes: 0/1/2 errors, third-error restart; server save/reload; number save/reload.');
