import assert from 'node:assert/strict';
import fs from 'node:fs';
import {harness,ready} from './ui-harness.mjs';
const course=JSON.parse(fs.readFileSync('lib/course.json'));
const h=await ready(harness(async()=>({ok:true,json:async()=>({player:null})})));
h.run('home()');
assert(h.buttons().some(b=>b.dataset.action==='myLessons'),'start screen has a My Route shortcut');
await h.click('action','myLessons');
assert.equal(h.run('state.screen'),'lessons');
assert(h.app.innerHTML.includes('Мои уроки.'));
assert.equal((h.app.innerHTML.match(/class="number-lesson /g)||[]).length,course.length,'lesson route uses the number course card layout');
assert.equal((h.app.innerHTML.match(/class="number-boss-card /g)||[]).length,course.length/5,'every fifth lesson has a separate boss card');
for(const q of course[0].items){assert(h.app.innerHTML.includes(q[0]));assert(h.app.innerHTML.includes(q[1]));}
assert(h.app.innerHTML.includes('БОСС · 01'));
assert(h.app.innerHTML.includes('Уроки 1–5'));
assert(h.app.innerHTML.includes('25 слов · 10 вариантов · до трёх ошибок'));
assert(h.app.innerHTML.includes('number-progress route-progress-card'));
h.run("state.answers[Study.lessonKey(0)]=Study.record('true');lessons()");
assert(h.app.innerHTML.includes('01 · '+course[0].title));
assert(h.app.innerHTML.includes('Пройден</span>'));
// Complete five lessons using the same transition engine and confirm the corresponding boss is available.
const answers=h.run(`(()=>{let a={};for(let n=0;n<5;n++){let t=Study.transition(a,missions,{kind:'lesson-start',lesson:n,order:[0,1,2,3,4],restart:false});a={...a,...t.patch};for(let i=0;i<5;i++){t=Study.transition(a,missions,{kind:'lesson-answer',lesson:n,round:0,index:i,choice:missions[n].items[i][0]});a={...a,...t.patch};}}return a;})()`);
h.run('state.answers='+JSON.stringify(answers)+';lessons()');
assert(h.app.innerHTML.includes('<strong>Уроки 1–5</strong><span>Доступен</span>'));
assert(h.buttons().some(b=>b.dataset.action==='boss'&&b.text.includes('Начать босса')));
console.log('PASS: My Lessons lists all lessons and bosses, displays boss status and vocabulary, and exposes an unlocked boss.');
