import assert from 'node:assert/strict';import fs from 'node:fs';import {setup} from './api-harness.mjs';import {Study} from '../lib/study-engine.js';
const api=await setup(),{call,db}=api;const course=JSON.parse(fs.readFileSync('lib/course.json'));
try{
 assert.equal((await call('me')).data.player,null);assert.equal((await call('register',{nick:'aa',password:'123'})).status,400);
 const p=await api.player('Api_Player');const stored=await db.prepare('SELECT * FROM players WHERE nick=?').bind('Api_Player').first();assert.notEqual(stored.hash,'Temporary-QA-5544');assert.equal(stored.hash.length,64);
 assert.equal((await call('register',{nick:'API_PLAYER',password:'Temporary-QA-5544'})).status,409);assert.equal((await call('login',{nick:'Api_Player',password:'Incorrect-5544'})).status,401);
 assert.equal((await call('study',{kind:'lesson-start',lesson:0})).status,401);assert.equal((await call('study',{kind:'lesson-start',lesson:0},p.cookie,'https://evil.test')).status,403);
 assert.equal((await call('study',{kind:'lesson-start',lesson:1},p.cookie)).status,409);assert.equal((await call('study',{kind:'boss-start',checkpoint:5},p.cookie)).status,409);
 let answers=(await call('me',undefined,p.cookie)).data.answers;
 async function study(command){if(command.kind==='lesson-start')command={...command,order:[0,1,2,3,4]};if(command.kind==='boss-start')command={...command,words:course.slice(command.checkpoint-5,command.checkpoint).flatMap(m=>m.items.map(q=>q[0]))};const r=await call('study',command,p.cookie);assert.equal(r.status,200,JSON.stringify(r.data));Object.assign(answers,r.data.patch);return r.data.view;}
 for(let n=0;n<5;n++){let v=await study({kind:'lesson-start',lesson:n});for(let i=0;i<5;i++)v=await study({kind:'lesson-answer',lesson:n,round:v.attempt.round,index:i,choice:course[n].items[i][0]});}
 assert.equal((await call('study',{kind:'lesson-start',lesson:5},p.cookie)).status,409);let b=(await study({kind:'boss-start',checkpoint:5})).boss;
 assert.equal(b.words.length,25);for(let i=0;i<3;i++){const word=b.words[i];b=(await study({kind:'boss-answer',checkpoint:5,round:b.round,index:i,choice:Study.options(b.words,word,course).find(w=>w!==word)})).boss;}
 assert(b.failed);assert.equal(Study.completed(answers,course),5);assert.equal((await call('study',{kind:'boss-answer',checkpoint:5,round:b.round,index:3,choice:b.words[3]},p.cookie)).status,409);
 const second=await call('login',{nick:'Api_Player',password:'Temporary-QA-5544'},'',undefined,'second-device');assert.equal(Study.boss(second.data.answers,5,course).errors,3);
 b=(await study({kind:'boss-start',checkpoint:5})).boss;assert.equal(b.index,0);assert.equal(b.errors,0);let final;
 for(let i=0;i<25;i++){final={kind:'boss-answer',checkpoint:5,round:b.round,index:i,choice:b.words[i]};b=(await study(final)).boss;}
 assert(b.done);assert((await study(final)).boss.done);assert.equal((await call('study',{kind:'lesson-start',lesson:5,order:[0,1,2,3,4]},p.cookie)).status,200);
 // Same-round concurrent answers cannot both consume a question.
 const lesson=(await call('study',{kind:'lesson-start',lesson:5,order:[0,1,2,3,4]},p.cookie)).data.view.attempt,q=course[5].items[0];const simultaneous=await Promise.all([call('study',{kind:'lesson-answer',lesson:5,round:lesson.round,index:0,choice:q[0]},p.cookie),call('study',{kind:'lesson-answer',lesson:5,round:lesson.round,index:0,choice:q[5].find(w=>w!==q[0])},p.cookie)]);assert(simultaneous.some(r=>r.status===200));const now=(await call('me',undefined,p.cookie)).data.answers,attempt=Study.attempt(now,5);assert.equal(attempt.choices.length,1);assert(attempt.failed||attempt.index===1);
 const other=await api.player('Other_Player');assert.equal(Study.completed((await call('me',undefined,other.cookie)).data.answers,course),0);
 assert.equal((await call('password',{currentPassword:'wrong',newPassword:'Next-password-5544'},p.cookie)).status,401);assert.equal((await call('password',{currentPassword:'Temporary-QA-5544',newPassword:'tiny'},p.cookie)).status,400);
 const changed=await call('password',{currentPassword:'Temporary-QA-5544',newPassword:'Next-password-5544'},p.cookie);assert.equal(changed.status,200);assert.equal((await call('me',undefined,second.cookie)).data.player,null);assert.equal(Study.completed((await call('me',undefined,changed.cookie)).data.answers,course),5);assert.equal((await call('login',{nick:'Api_Player',password:'Temporary-QA-5544'})).status,401);
 assert.equal((await call('logout',{},changed.cookie)).status,200);assert.equal((await call('me',undefined,changed.cookie)).data.player,null);
 console.log('PASS API: auth/password/session isolation/CSRF, lesson/boss gates, 25 words, persisted three-error failure, boss-only reset, duplicate final retry, concurrent-tab guard, preserved progress.');
}finally{await api.mf.dispose();}
