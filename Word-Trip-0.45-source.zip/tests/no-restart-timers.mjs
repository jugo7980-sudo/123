import assert from 'node:assert/strict';
import {harness,ready} from './ui-harness.mjs';
const h=await ready(harness(async()=>({ok:true,json:async()=>({player:null})})));
// Complete the first five lessons in the shared transition engine to unlock the boss.
const answers=h.run(`(()=>{let a={};for(let n=0;n<5;n++){let t=Study.transition(a,missions,{kind:'lesson-start',lesson:n,order:[0,1,2,3,4],restart:false});a={...a,...t.patch};for(let i=0;i<5;i++){t=Study.transition(a,missions,{kind:'lesson-answer',lesson:n,round:0,index:i,choice:missions[n].items[i][0]});a={...a,...t.patch};}}return a;})()`);
h.run('state.answers='+JSON.stringify(answers));h.run('progressChanged();home()');
h.run('Math.random=()=>0');await h.click('action','start');
assert.equal(h.run('state.screen'),'boss');
const firstWord=h.run('state.boss.words[state.bossIndex]'),firstQuestion=h.run('QUESTION_BY_WORD.get(state.boss.words[state.bossIndex])');
const bossSpoken=[];h.c.window.speechSynthesis.speak=u=>bossSpoken.push({text:u.text,rate:u.rate});
await h.click('bossChoice',firstWord);h.drain();assert.equal(bossSpoken.at(-1).text,firstWord,'correct boss answer speaks only the English word, not the example sentence');assert.equal(bossSpoken.at(-1).rate,.9,'automatic boss speech uses normal speed');await h.click('action','bossNext');
assert(!h.buttons().some(b=>['sentenceAudio','sentenceAudioSlow'].includes(b.dataset.action)),'boss has no full-sentence playback buttons');
for(let i=0;i<3;i++){
 if(i)await h.click('action','bossNext');
 const word=h.run('state.boss.words[state.bossIndex]');
 const wrong=h.buttons().find(b=>b.dataset.bossChoice&&b.dataset.bossChoice!==word);assert(wrong);
 await h.click('bossChoice',wrong.dataset.bossChoice);
 if(i<2){assert(h.buttons().some(b=>b.dataset.action==='bossNext'&&b.text.includes('Следующий вопрос')));assert(!h.buttons().some(b=>b.dataset.action==='bossRestart'),'restart must not appear before the third error');}
}
assert.equal(h.run('state.boss.errors'),3);
assert(h.app.innerHTML.includes('Три ошибки. Нажми «Хорошо»'));
assert(!h.buttons().some(b=>b.dataset.action==='bossRestart'),'restart button appears after the 3.5s delay');
assert(h.app.innerHTML.includes('Через 3,5 секунды появится кнопка'));
for(const action of ['home','toggleSound'])assert(h.buttons().some(b=>b.dataset.action===action&&!b.disabled),`${action} stays available during the restart delay`);
assert(h.tasks.some(t=>t.ms===3500),'the delayed button timer is 3.5 seconds');
h.drain();
assert(h.buttons().some(b=>b.dataset.action==='bossRestart'&&b.text.includes('Хорошо')));
for(const action of ['home','toggleSound'])assert(h.buttons().some(b=>b.dataset.action===action&&!b.disabled),`${action} remains available after the restart button appears`);
h.run('Math.random=()=>0.999');await h.click('action','bossRestart');
assert.equal(h.run('state.boss.round'),1);
assert.equal(h.run('state.screen'),'boss');
console.log('PASS: after three boss errors, the boss waits for OK and starts again in a new round.');
