import assert from 'node:assert/strict';import fs from 'node:fs';import {Study} from '../lib/study-engine.js';
const course=JSON.parse(fs.readFileSync('lib/course.json'));assert.equal(course.length,200);assert.equal(new Set(course.flatMap(m=>m.items.map(q=>q[0]))).size,1000);
let a={};Object.assign(a,Study.migrate(a,course));let bosses=0;
function command(cmd){if(cmd.kind==='lesson-start'&&!cmd.order)cmd={...cmd,order:[0,1,2,3,4]};const r=Study.transition(a,course,cmd);Object.assign(a,r.patch);return r.view;}
for(let n=0;n<200;n++){
 assert.equal(Study.due(a,course),null,'no boss before five passed lessons');let v=command({kind:'lesson-start',lesson:n});
 assert.throws(()=>command({kind:'lesson-start',lesson:n+1}),/предыдущий|нет/);
 for(let i=0;i<course[n].items.length;i++){const q=course[n].items[v.attempt.questions[i]];assert.equal(q[5].length,6);assert.equal(new Set(q[5]).size,6);const lessonChoices=Study.lessonOptions(q,course);assert.equal(lessonChoices.length,8);assert.equal(new Set(lessonChoices).size,8);
  if(i===2){v=command({kind:'lesson-answer',lesson:n,round:v.attempt.round,index:i,choice:q[5].find(w=>w!==q[0])});assert(v.attempt.failed);assert(!Study.passed(a,n));assert.throws(()=>command({kind:'lesson-answer',lesson:n,round:v.attempt.round,index:i+1,choice:q[0]}));v=command({kind:'lesson-start',lesson:n});assert.equal(v.attempt.index,0);for(let j=0;j<i;j++)v=command({kind:'lesson-answer',lesson:n,round:v.attempt.round,index:j,choice:course[n].items[j][0]});}
  v=command({kind:'lesson-answer',lesson:n,round:v.attempt.round,index:i,choice:q[0]});
 }
 assert(Study.passed(a,n));assert.equal(Study.completed(a,course),n+1);
 if((n+1)%5===0){const cp=n+1;assert.equal(Study.due(a,course),cp);if(n<199)assert.throws(()=>command({kind:'lesson-start',lesson:n+1,order:[0,1,2,3,4]}),/босса/);const expected=course.slice(cp-5,cp).flatMap(m=>m.items.map(q=>q[0]));let b=command({kind:'boss-start',checkpoint:cp,words:expected}).boss;assert.deepEqual(b.words,expected);assert.equal(b.words.length,25);
  for(let i=0;i<3;i++){const word=b.words[i],options=Study.options(b.words,word,course);assert.equal(options.length,10);assert.equal(new Set(options).size,10);b=command({kind:'boss-answer',checkpoint:cp,round:b.round,index:i,choice:options.find(w=>w!==word)}).boss;assert.equal(b.errors,i+1);assert.equal(b.failed,i===2);if(i===0){const resumed=command({kind:'boss-start',checkpoint:cp,words:[...expected].reverse()}).boss;assert.equal(resumed.index,1);assert.equal(resumed.errors,1);assert.deepEqual(resumed.words,expected);b=resumed;}}
  assert.equal(Study.completed(a,course),cp,'boss failure never resets lessons');b=command({kind:'boss-start',checkpoint:cp,words:[...expected].reverse(),restart:true}).boss;assert.equal(b.index,0);assert.equal(b.errors,0);assert.notDeepEqual(b.words,expected);assert.deepEqual(b.words,[...expected].reverse());
  let last;for(let i=0;i<b.words.length;i++){const word=b.words[i],choice=i<2?Study.options(b.words,word,course).find(w=>w!==word):word;last={kind:'boss-answer',checkpoint:cp,round:b.round,index:i,choice};b=command(last).boss;}
  assert(b.done);assert.equal(b.errors,2);assert.equal(Study.due(a,course),null);assert(command(last).boss.done,'lost final response can retry idempotently');bosses++;
 }
}
assert.equal(bosses,40);assert.equal(Study.completed(a,course),200);
const legacy=Object.fromEntries(course.flatMap(m=>m.items).slice(0,17).map(q=>[q[0],{choice:q[0]}]));Object.assign(legacy,Study.migrate(legacy,course));assert.equal(Study.completed(legacy,course),3);assert.equal(Study.due(legacy,course),null);assert.equal(Study.attempt(legacy,3).index,0);
console.log('PASS: 200 lessons, 1000 words, 40 bosses × all 25 words; 6/8 unique choices; lesson errors restart lesson; third boss error restarts boss only; two errors allowed; milestone gates, idempotency and legacy migration.');
