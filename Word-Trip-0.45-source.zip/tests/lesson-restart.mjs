import assert from 'node:assert/strict';
import {harness,ready} from './ui-harness.mjs';
import fs from 'node:fs';

const course=JSON.parse(fs.readFileSync('lib/course.json'));
const fetcher=async()=>({ok:true,json:async()=>({player:null})});
let h=await ready(harness(fetcher));
await h.click('action','start');
for(let i=0;i<4;i++){
  const q=course[0].items[h.run('state.attempt.questions[state.index]')];
  await h.click('choice',q[0]);h.drain();await h.click('action','next');
}
const q=course[0].items[h.run('state.attempt.questions[state.index]')];
await h.click('choice',q[5].find(w=>w!==q[0]));
assert(!h.tasks.some(t=>t.ms===3500),'lesson errors do not trigger an automatic timer');
assert(h.app.innerHTML.includes('Нажми «Хорошо»'));
assert(h.buttons().some(b=>b.dataset.action==='retryLesson'));
assert(!h.buttons().some(b=>b.dataset.action==='next'));
const order=Array.from(h.run('state.attempt.questions'));
await h.click('action','retryLesson');
assert.equal(h.run('state.index'),0);
assert.equal(h.run('state.attempt.round'),1);
assert.notDeepEqual(Array.from(h.run('state.attempt.questions')),order,'retry starts a fresh shuffled lesson');
assert.equal(h.run('Study.completed(state.answers,missions)'),0);
console.log('PASS: a wrong verb answer waits for the OK button, then restarts the lesson in a new order; the next lesson remains locked.');
