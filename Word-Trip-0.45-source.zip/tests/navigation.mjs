import assert from 'node:assert/strict';import fs from 'node:fs';import {harness,ready} from './ui-harness.mjs';import {setup} from './api-harness.mjs';
const course=JSON.parse(fs.readFileSync('lib/course.json'));const api=await setup();
async function settle(h){h.drain();for(let i=0;i<600&&h.run('!!pendingSave||busy');i++)await new Promise(r=>setTimeout(r,5));assert(!h.run('!!pendingSave||busy'),'save/restart settled');h.drain();}
async function full(fetcher,label,disk={}){
 let h=await ready(harness(fetcher,disk));await h.click('action','updates');assert(h.app.innerHTML.includes('0.13'));await h.click('action','home');await h.click('action','lessons');assert.equal(h.buttons().filter(b=>b.dataset.lesson).length,200);await h.click('action','home');await h.click('action','start');
 const failed=new Set(),failedBosses=new Set();let bosses=0,steps=0,loaded=false;
 while(steps++<8000){
  const screen=h.run('state.screen');
  if(screen==='question'){
   const n=h.run('state.mission'),i=h.run('state.index'),q=course[n].items[h.run('state.attempt.questions[state.index]')];assert.equal(h.buttons().filter(b=>b.dataset.choice).length,8);
   if(!failed.has(n)&&i===2){failed.add(n);await h.click('choice',q[5].find(w=>w!==q[0]));assert(h.app.innerHTML.includes('wrong'));assert(!h.buttons().some(b=>b.dataset.action==='next'));assert(h.tasks.some(t=>t.ms===3500));await settle(h);assert.equal(h.run('state.index'),0);continue;}
   await h.click('choice',q[0]);await settle(h);await h.click('action','next');
  }else if(screen==='result'){
   const n=h.run('state.mission')+1;assert.equal(!!h.run('pendingBoss()'),n%5===0);await h.click('action','home');assert.equal(h.app.innerHTML.includes('Пройти босса →'),n%5===0);await h.click('action','start');
  }else if(screen==='boss'){
   const cp=h.run('state.boss.checkpoint'),i=h.run('state.bossIndex'),words=h.run('state.boss.words');assert.equal(words.length,25);assert.deepEqual([...words].sort(),course.slice(cp-5,cp).flatMap(m=>m.items.map(q=>q[0])).sort());assert.equal(h.buttons().filter(b=>b.dataset.bossChoice).length,10);
   const errorRound=!failedBosses.has(cp),wrong=errorRound?i<3:i<2,word=words[i],choice=wrong?h.run('bossOptions(state.boss.words,state.boss.words[state.bossIndex]).find(w=>w!==state.boss.words[state.bossIndex])'):word;
   const lessons=h.run('Study.completed(state.answers,missions)');await h.click('bossChoice',choice);
   if(errorRound&&i===2){failedBosses.add(cp);assert(h.run('state.boss.failed'));assert(!h.buttons().some(b=>b.dataset.action==='bossNext'));await settle(h);assert.equal(h.run('state.screen'),'boss');assert.equal(h.run('state.bossIndex'),0);assert.equal(h.run('state.boss.errors'),0);assert.equal(h.run('Study.completed(state.answers,missions)'),lessons);assert.notDeepEqual(Array.from(h.run('state.boss.words')),Array.from(words),'boss retry must shuffle questions');continue;}
   if(wrong){assert.equal(h.run('state.boss.errors'),i+1);assert(!h.run('state.boss.failed'));}
   await settle(h);await h.click('action','bossNext');
   if(!loaded&&h.run('state.screen')==='boss'&&h.run('state.bossIndex')===2){loaded=true;h=await ready(harness(fetcher,h.disk));await h.click('action','start');assert.equal(h.run('state.screen'),'boss');assert.equal(h.run('state.bossIndex'),2);assert.equal(h.run('state.boss.errors'),2);}
  }else if(screen==='bossResult'){
   bosses++;assert(h.app.innerHTML.includes('23 / 25'));await h.click('action','home');assert(!h.app.innerHTML.includes('Пройти босса →'));await h.click('action',h.run('nextMission()')<0?'words':'start');
  }else if(screen==='words'){assert.equal(h.run('Study.completed(state.answers,missions)'),200);assert.equal(h.run('total()'),1000);break;}
  else throw Error('unexpected '+screen);
 }
 assert(steps<8000);assert.equal(bosses,40);console.log(`PASS ${label}: all 200 lessons / 40 bosses / 1000 boss questions, lesson and boss failure loops, 6/8 choices, two tolerated errors, 3.5s pauses, reload with lives, home/lesson map/history/vocabulary.`);
}
try{
 await full(async()=>({ok:true,json:async()=>({player:null})}),'guest');
 const p=await api.player('Full_Course');await full(p.fetcher,'account');
 const legacy=await api.player('Legacy_Course');const row=await api.db.prepare('SELECT id FROM players WHERE nick=?').bind('Legacy_Course').first();await api.db.prepare("DELETE FROM answers WHERE player_id=? AND word GLOB '__wt_study_v2:*'").bind(row.id).run();for(const q of course.flatMap(m=>m.items).slice(0,17))await api.db.prepare('INSERT INTO answers (player_id,word,choice,hint,created) VALUES (?,?,?,0,1)').bind(row.id,q[0],q[0]).run();
 const h=await ready(harness(legacy.fetcher));assert.equal(h.run('Study.completed(state.answers,missions)'),3);await h.click('action','start');assert.equal(h.run('state.mission'),3);assert.equal(h.run('state.index'),0);assert(!h.run('pendingBoss()'));console.log('PASS legacy migration: prior completed lessons and all words preserved, partial lesson restarts cleanly, no mid-lesson boss.');
}finally{await api.mf.dispose();}
