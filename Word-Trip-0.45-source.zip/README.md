# Word Trip

English vocabulary course for Russian speakers: 200 lessons, five distinct words or expressions per lesson, 1000 targets.

## Study flow (0.11)

- A lesson has six answer choices per question. One incorrect answer shows red feedback and a failure sound, then restarts that lesson after 3.5 seconds. Only a complete successful attempt marks the lesson passed.
- A boss appears after five passed lessons: 1–5, 6–10, and so on. It never interrupts a lesson. The next block stays locked until the boss is passed.
- Each boss tests all 25 words from its five lessons, with eight unique choices per question. The first two mistakes allow continuation. The third mistake restarts the boss after 3.5 seconds, with errors and question index reset. Lesson progress is preserved.
- Pending bosses appear on the home page. Passed and unavailable bosses are hidden.
- Current attempts, question index and boss errors survive reload and account sign-in on another device.
- Earlier completed lessons and vocabulary are retained during migration. Old five-task boss records stay in storage but do not control the new route.

## Implementation

`lib/study-engine.js` owns deterministic rules shared by browser and Worker API. `scripts/sync-study-client.mjs` embeds the exact same engine in `public/app.js`; dev/build sync it automatically. Do not edit the generated engine block directly.

D1 stores nickname/password profiles, hashed credentials and sessions, and progress. New attempt and completion records use the reserved `__wt_study_v2:` namespace. No destructive schema migration is needed. The API validates sequence, attempt round and milestones; atomic guarded batches prevent conflicting tab writes from advancing a question twice. Retrying a lost response is idempotent, including the final boss answer.

The browser renders feedback immediately and submits sparse progress updates. Next and other navigation wait for server acknowledgement; an uncertain save can be retried. Guest storage and speech are deferred until after paint. Guest progress can be imported explicitly from the account menu.

Correct answers speak the full English sentence. Audio depends on installed browser/phone voices. The mobile boss layout supports eight choices and feedback in a compact two-column layout.

## Checks

- `node tests/course.mjs`: all course content, 200 lesson failure/retry loops, 40 bosses, 25-word coverage, 6/8 choices, three-error policy, migration and idempotency.
- `node tests/navigation.mjs`: full guest and account journeys through actual rendered button handlers, all lessons and bosses, errors, reload, lives, history, map and vocabulary; legacy account migration.
- `node tests/player-api.mjs`: isolated Worker/D1 auth, password, CSRF, milestone gates, boss errors, concurrent writes and response retries.
- `node tests/responsiveness.mjs`: feedback before network acknowledgement, navigation locking and failed-save retry.
- `node tests/lesson-restart.mjs`: a last-question error restarts the whole lesson and survives reload.

Internal browser QA also checks the mobile layout and boss failure flow. Automated tests do not verify actual audible output on a user's phone.

## History and hosting

`lib/releases.json` is the canonical concise Russian update log. Keep the browser `RELEASES` constant identical and bump changed asset versions. Site identity remains in `.openai/hosting.json`; use Sites source/build/publishing helpers.
