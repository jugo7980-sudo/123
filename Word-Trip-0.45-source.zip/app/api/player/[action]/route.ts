import {env} from 'cloudflare:workers';
import {handle} from '../../../../lib/player-api';
export const dynamic='force-dynamic';
async function route(req:Request){return handle(req,(env as any).DB,new URL(req.url).pathname.split('/').pop()||'');}
export const GET=route;export const POST=route;
