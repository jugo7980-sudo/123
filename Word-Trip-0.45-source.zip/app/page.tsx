'use client';
import {useEffect} from 'react';
export default function Page(){useEffect(()=>{const s=document.createElement('script');s.src='/app.js?v=study45';s.id='word-trip-code';if(!document.getElementById(s.id))document.body.appendChild(s);},[]);return <main id="app"><p>Загружаем игру…</p></main>}
