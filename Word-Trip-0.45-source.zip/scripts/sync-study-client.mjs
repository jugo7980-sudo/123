import fs from 'node:fs';
const engine=fs.readFileSync(new URL('../lib/study-engine.js',import.meta.url),'utf8').replace('export const Study=','const Study=');
const p=new URL('../public/app.js',import.meta.url);let s=fs.readFileSync(p,'utf8');const start='// BEGIN SHARED STUDY ENGINE',end='// END SHARED STUDY ENGINE';
if(s.includes(start))s=s.slice(0,s.indexOf(start))+s.slice(s.indexOf(end)+end.length);
s=start+'\n'+engine+'\n'+end+'\n'+s.trimStart();for(const [name,file] of [['missions','course'],['RELEASES','releases']]){
 const data=JSON.parse(fs.readFileSync(new URL('../lib/'+file+'.json',import.meta.url),'utf8'));
 const pattern=new RegExp('^const '+name+'=.*;$','m');
 if(!pattern.test(s))throw new Error('Missing browser data: '+name);
 s=s.replace(pattern,()=> 'const '+name+'='+JSON.stringify(data)+';');
}
fs.writeFileSync(p,s);
