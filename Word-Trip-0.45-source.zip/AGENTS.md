# Word Trip update history

User requirement: maintain a permanent, very concise Russian update history for every published feature, fix, or adjustment.

- `lib/releases.json` is the canonical history, newest first. The first entry is the current public version.
- Increment the minor number for each published update (current format `0.x`; read the latest entry before incrementing). Do not change previous entries or imply unrelated features were added.
- Add the actual release date and short plain Russian bullets describing changes.
- Keep the `RELEASES` constant in `public/app.js` identical to this JSON. The small header label and history screen use it.
- Bump the script/style cache versions when their corresponding assets change.
- When asked what changed, read the current release history and answer briefly.
- Keep this history in the Site source repository so it remains available across conversations.
